//
//  Valores.swift
//  CreaTuPizzaIW
//
//  Created by Juan Felipe Chávez on 29/05/16.
//  Copyright © 2016 JuanFelipeChávez. All rights reserved.
//

import WatchKit

class Valores: NSObject {




    var Error : String = ""

    var TipoPantalla : Int=0
    var TodoslosIngredientes = [""]



    var TamanioPizza:String=""
    var TipoDeMasa:String=""
    var TipoDeQueso:String=""
    var totIng:Int=0

    //var ingredienteSel:[String]=[]

    var vIngredientes: Set<String> = []

    override init(){
        self.TamanioPizza = ""
        self.TipoDeMasa=""
        self.TipoDeQueso=""
        self.totIng=0
    }

    func setTamaño(tam:String)
    {
        self.TamanioPizza = tam
    }

    func setMasa(mas:String)
    {
        self.TipoDeMasa = mas
    }

    func setQueso(que:String)
    {
        self.TipoDeQueso = que
    }


    func addIngrediente(ing:String)->Int
    {
        vIngredientes.insert(ing)
        totIng += 1
        return totIng
    }

    func remIngrediente(ing:String)->Int
    {
        vIngredientes.remove(ing)
        totIng -= 1
        return totIng
    }


    func totalIng() -> Int
    {
        return totIng
    }


    func imprimir()
    {
        print("valores: \(TamanioPizza) - \(TipoDeMasa) - \(TipoDeQueso)")
    }



}