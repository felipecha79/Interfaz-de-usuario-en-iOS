//
//  InterfaceController.swift
//  CreaTuPizzaIW WatchKit Extension
//
//  Created by Juan Felipe Chávez on 29/05/16.
//  Copyright © 2016 JuanFelipeChávez. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet var dtpTamanios: WKInterfacePicker!
    @IBOutlet var lblResultTamanio: WKInterfaceLabel!
    var valores = Valores()

        var pickerItems: [WKPickerItem]?
    var ResultadoActual : String = ""

    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.


        let itemList: [(String)] = [
            ("Chica"),
            ("Mediana"),
            ("Grande")]


        pickerItems = (itemList).map {
            let pickerItem = WKPickerItem()
            pickerItem.title = "\($0)"
            return pickerItem
        }
        dtpTamanios.setItems(pickerItems)


    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    @IBAction func dlpTamanios(value: Int) {

        switch value {
            case 0:
             lblResultTamanio.setText("Chica")
             valores.setTamaño("Chica")
            case 1:
             lblResultTamanio.setText("Mediana")
             valores.setTamaño("Mediana")
            case 2:
            lblResultTamanio.setText("Grande")
            valores.setTamaño("Grande")
            default:
              lblResultTamanio.setText("Selección no válida")
            }

    }

    @IBAction func btnSiguiente() {

        valores.imprimir()
        pushControllerWithName("IdentificadorValorTamanio", context: valores)

    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
