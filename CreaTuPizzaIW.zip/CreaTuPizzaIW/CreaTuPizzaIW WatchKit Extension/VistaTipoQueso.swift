//
//  VistaTipoQueso.swift
//  CreaTuPizzaIW
//
//  Created by Juan Felipe Chávez on 29/05/16.
//  Copyright © 2016 JuanFelipeChávez. All rights reserved.
//

import WatchKit
import Foundation


class VistaTipoQueso: WKInterfaceController {

    @IBOutlet var pkeOpcionesQueso: WKInterfacePicker!
    @IBOutlet var lblResultadoQueso: WKInterfaceLabel!
    var pickerItems: [WKPickerItem]?
    var TMasa : String = ""
    var ResultadoActual : String = ""

     var ArrValorContexto = ["":[""]]

    var valores = Valores()


    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)

        //Comenzamos a llenar el picker


        let itemList: [(String)] = [
            ("Mozarela"),
            ("Chedar"),
            ("Parmesano"),
            ("Sin Queso")]


        pickerItems = (itemList).map {
            let pickerItem = WKPickerItem()
            pickerItem.title = "\($0)"
            return pickerItem
        }
        pkeOpcionesQueso.setItems(pickerItems)

        //Comenzamos con la asignación de valores

        let c = context as! Valores
        valores = c

    }

    @IBAction func pkeOpcionesQueso(value: Int) {

        switch value {
        case 0:
            lblResultadoQueso.setText("Mozarela")
            valores.setQueso("Mozarela")
        case 1:
            lblResultadoQueso.setText("Chedar")
            valores.setQueso("Chedar")
        case 2:
            lblResultadoQueso.setText("Parmesano")
            valores.setQueso("Parmesano")
        case 3:
            lblResultadoQueso.setText("Sin Queso")
            valores.setQueso("Sin Queso")

        default:
            lblResultadoQueso.setText("Selección no válida")
        }
        valores.imprimir()

    }
    @IBAction func btnSiguiente() {
        print(valores.TamanioPizza)

        pushControllerWithName("IdentificadorValorQueso", context: valores)

    }
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
