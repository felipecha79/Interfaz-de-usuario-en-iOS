//
//  VistaDetalle_InterfaceController.swift
//  CreaTuPizzaIW
//
//  Created by Juan Felipe Chávez on 29/05/16.
//  Copyright © 2016 JuanFelipeChávez. All rights reserved.
//

import WatchKit
import Foundation


class VistaDetalle_InterfaceController: WKInterfaceController {

    @IBOutlet var lblResultadoMasa: WKInterfacePicker!
    @IBOutlet var ValorMasa: WKInterfaceLabel!
    var pickerItems: [WKPickerItem]?
    var TPizza : String = ""
    var ResultadoActual : String = ""

    var ArrValorContexto = ["":[""]]

    var valores = Valores()

    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)

        //Comenzamos a llenar el picker

        let itemList: [(String)] = [
            ("Delgada"),
            ("Crujiente"),
            ("Gruesa")]


        pickerItems = (itemList).map {
            let pickerItem = WKPickerItem()
            pickerItem.title = "\($0)"
            return pickerItem
        }
        lblResultadoMasa.setItems(pickerItems)

        //Comenzamos con la asignación de valores

        let c = context as! Valores
        valores = c
        

  
    }
    @IBAction func lblResultadoMasa(value: Int) {

        switch value {
        case 0:
            ValorMasa.setText("Delgada")
            valores.setMasa("Delgada")
        case 1:
            ValorMasa.setText("Crujiente")
            valores.setMasa("Crujiente")
        case 2:
            ValorMasa.setText("Gruesa")
            valores.setMasa("Gruesa")
        default:
            ValorMasa.setText("Selección no válida")
        }


    }

    @IBAction func btnSiguiente() {


        pushControllerWithName("IdentificadorValorMasa", context: valores)


    }
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
