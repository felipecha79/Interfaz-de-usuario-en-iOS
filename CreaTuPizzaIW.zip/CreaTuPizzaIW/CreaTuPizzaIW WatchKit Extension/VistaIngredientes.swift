//
//  VistaIngredientes.swift
//  CreaTuPizzaIW
//
//  Created by Juan Felipe Chávez on 29/05/16.
//  Copyright © 2016 JuanFelipeChávez. All rights reserved.
//

import WatchKit
import Foundation


class VistaIngredientes: WKInterfaceController {

    @IBOutlet var lblResIngredientes: WKInterfaceLabel!
     var valores = Valores()

//Switches

    @IBOutlet var voJamon: WKInterfaceSwitch!
    @IBOutlet var voPavo: WKInterfaceSwitch!
    @IBOutlet var voSalchicha: WKInterfaceSwitch!
    @IBOutlet var voAceituna: WKInterfaceSwitch!
    @IBOutlet var voCebolla: WKInterfaceSwitch!
    @IBOutlet var voPimiento: WKInterfaceSwitch!
    @IBOutlet var voPiña: WKInterfaceSwitch!
    @IBOutlet var voAnchoa: WKInterfaceSwitch!

//Boton


    @IBOutlet var btnSiguiente: WKInterfaceButton!


//Variables

    var TQueso : String = ""
    var ResultadoActual : String = ""

    var ArrValorContexto = ["":[""]]

    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        


        //Comenzamos con la asignación de valores

        let c = context as! Valores
        valores = c

        valores.imprimir()
        //revisaSeleccionados()


    }


    @IBAction func vaJamon(value: Bool) {

        if value{
            agregaIngrediente("Jamon", contr: 1)}
        else{
            quitaIngrediente("Jamon")}

        print(valores.vIngredientes.enumerate())
    }


    @IBAction func vaPavo(value: Bool) {
        if value{
            agregaIngrediente("Pavo", contr: 1)}
        else{
            quitaIngrediente("Pavo")}

        print(valores.vIngredientes.enumerate())
    }

    @IBAction func vaSalchicha(value: Bool) {
        if value{
            agregaIngrediente("Salchicha", contr: 1)}
        else{
            quitaIngrediente("Salchicha")}

        print(valores.vIngredientes.enumerate())
    }

    @IBAction func vaAceituna(value: Bool) {
        if value{
            agregaIngrediente("Aceituna", contr: 1)}
        else{
            quitaIngrediente("Aceituna")}

        print(valores.vIngredientes.enumerate())
    }

    @IBAction func vaCebolla(value: Bool) {
        if value{
            agregaIngrediente("Cebolla", contr: 1)}
        else{
            quitaIngrediente("Cebolla")}

        print(valores.vIngredientes.enumerate())
    }

    @IBAction func vaPimiento(value: Bool) {
        if value{
            agregaIngrediente("Pimiento", contr: 1)}
        else{
            quitaIngrediente("Pimiento")}

        print(valores.vIngredientes.enumerate())
    }

    @IBAction func vaPinia(value: Bool) {
        if value{
            agregaIngrediente("Piña", contr: 1)}
        else{
            quitaIngrediente("Piña")}

        print(valores.vIngredientes.enumerate())
    }

    @IBAction func vaAnchoa(value: Bool) {
        if value{
            agregaIngrediente("Anchoa", contr: 1)}
        else{
            quitaIngrediente("Anchoa")}

        print(valores.vIngredientes.enumerate())
    }


    @IBAction func sigGesto() {

pushControllerWithName("IdentificadorValorIngredientes", context: valores)

    }


    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    //Funciones de control

    func agregaIngrediente(ingred:String, contr:Int)
    {
        if valores.totIng<5
        {
            valores.addIngrediente(ingred)
            btnSiguiente.setEnabled(true)
        }
        else
        {

            switch contr{
            case 1:
                voJamon.setOn(false)
            case 2:
                voPavo.setOn(false)
            case 3:
                voSalchicha.setOn(false)
            case 4:
                voAceituna.setOn(false)
            case 5:
                voCebolla.setOn(false)
            case 6:
                voPimiento.setOn(false)
            case 7:
                voPiña.setOn(false)
            case 8:
                voAnchoa.setOn(false)
            default: btnSiguiente.setEnabled(true)

            }
            pushControllerWithName("vistaMensaje", context: valores)

        }
    }

    func quitaIngrediente(ingred:String){
        valores.remIngrediente(ingred)
        if valores.totIng==0{
            //btnSiguiente.setEnabled(false)
        }
    }

    func revisaSeleccionados(){
        let ingSel = valores.vIngredientes
        for ingrediente in ingSel
        {
            switch ingrediente{
            case "Jamon":
                voJamon.setOn(true)
            case "Pavo":
                voPavo.setOn(true)
            case "Salchicha":
                voSalchicha.setOn(true)
            case "Aceituna":
                voAceituna.setOn(true)
            case "Cebolla":
                voCebolla.setOn(true)
            case "Pimiento":
                voPimiento.setOn(true)
            case "Piña":
                voPiña.setOn(true)
            case "Anchoa":
                voAnchoa.setOn(true)
            default: btnSiguiente.setEnabled(true)

            }
        }
    }


}
